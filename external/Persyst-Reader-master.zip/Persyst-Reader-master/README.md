Persyst-Reader
==============

Allows users to read Persyst .lay files in Matlab
